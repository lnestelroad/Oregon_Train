/*
CSCI 1300 spring
Author: Liam Nestelroad
Assignment: Homework 8; Oregon Trail Driver
Rectitaion: 103 - Arcaida Zhang
Cloun9 Workspace Editor Link: https://ide.c9.io/line4246/csci1300_amish
*/

#include <iostream>
#include <string> 
#include "Wagon.h"
using namespace std;

void Misfortune()
{
    //this function will simulate the misfortune chance and the puzzles.
    //a 40 percent change for a missfortune will occure every round
    //one miss fortune will be chosen at randome the player.

    //depending on the mis fortune, a specific consquence will happen.
}

void shop()
{
    //here is where the shop simulation will go
    
    //the is run at the very beginning of the game so that the user has a chance to buy materials.
    //depending on what shop the user is at, a[l prices will bbe increasedl]
}

void raiders()
{
    //function that will similate a raider attack and the options the user can do,

    //raiders eill be given a specifioc chance to invade.

    //if an invasion occurs, the user will be given options on how to proceed.
}

void menu()
{
    //here is where each turn will be simulatied.
    //the user will be given every option through thise function.
}

int main()
{
    int miles = 0;
    cout << "Welcome to The Oregon Trail!" << endl;

    Wagon one = Wagon();

    shop();
    while (miles < 2048)
    {
        main();
    }
}