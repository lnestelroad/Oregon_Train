/*
CSCI 1300 spring
Author: Liam Nestelroad
Assignment: Homework 8; project proposal
Rectitaion: 103 - Arcaida Zhang
Cloun9 Workspace Editor Link: https://ide.c9.io/line4246/csci1300_amish
*/

/**
Monopoly:

1. User Defined Classes:
	A. The board
	B. The player
	C. The properties

2. Data Members:
	A. The board will keep track of the users playing, the current amount in the free parking, the properties on the board, and the community Chest/chance  cards
	B. Each player class will keep track of the piece type, money, position, and property ownership
	C.
*/
